# A Methodology and Clinical Dataset with Ground-truth to Evaluate Registration Accuracy Quantitatively in Computer-assisted Laparoscopic Liver Resection
# N. Rabbani, L. Calvet, Y. Espinel, B. Le Roy, M. Ribeiro, E. Buc and A. Bartoli

This is the data, code and registration results for the evaluation of registration accuracy in computer-assisted laparoscopic liver resection. 
The dataset is provided for research purposes only.
It cannot be reproduced or modified without explicit agreement from the authors.
The results and testing of registration methods should be reported to the authors for possible inclusion on the companion webpage.
You are free to use the evaluation results in your publications should you read and cite our paper "A Methodology and Clinical Dataset with Ground-truth to Evaluate Registration Accuracy Quantitatively in Computer-assisted Laparoscopic Liver Resection" by N. Rabbani, L. Calvet, Y. Espinel, B. Le Roy, M. Ribeiro, E. Buc and A. Bartoli.

Run Evaluation.m to calculate the Inclusion Criterion and the Target Registration Error.
More information about the dataset and how to use it is available from http://igt.ip.uca.fr/~ab.

